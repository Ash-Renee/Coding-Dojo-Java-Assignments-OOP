public class MammalTest {
	public static void main(String[] args) {
		Gorilla Gerald = new Gorilla();
		Bat Spot = new Bat();
		Gerald.displayEnergy(); 
		Gerald.throwSomething();
		Gerald.displayEnergy();
		Gerald.throwSomething();
		Gerald.throwSomething();
		Gerald.displayEnergy();
		Gerald.eatBananas();
		Gerald.eatBananas();
		Gerald.displayEnergy();
		Gerald.climb();
		Gerald.displayEnergy();
		Spot.displayEnergy(); 
		Spot.attackTown();
		Spot.displayEnergy();
		Spot.attackTown();
		Spot.attackTown();
		Spot.displayEnergy();
		Spot.eatHumans();
		Spot.eatHumans();
		Spot.displayEnergy();
		Spot.fly();
		Spot.displayEnergy();
		Spot.fly();
		Spot.displayEnergy();
		}
}
