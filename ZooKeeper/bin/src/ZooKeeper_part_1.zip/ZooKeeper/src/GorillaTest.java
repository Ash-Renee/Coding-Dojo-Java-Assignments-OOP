
public class GorillaTest {
	public static void main(String[] args) {
		Gorilla Gerald = new Gorilla(100);
		Gerald.displayEnergy(); 
		Gerald.throwSomething();
		Gerald.displayEnergy();
		Gerald.throwSomething();
		Gerald.throwSomething();
		Gerald.displayEnergy();
		Gerald.eatBananas();
		Gerald.eatBananas();
		Gerald.displayEnergy();
		Gerald.climb();
		Gerald.displayEnergy();
		}
}
