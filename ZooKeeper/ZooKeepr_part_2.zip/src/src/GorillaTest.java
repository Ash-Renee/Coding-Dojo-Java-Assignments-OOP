src.src

public class GorillaTest {
	public static void main(String[] args) {
		Gorilla Gerald = new Gorilla(100);
		Gerald.displayEnergyA(); 
		Gerald.throwSomething();
		Gerald.displayEnergyA();
		Gerald.throwSomething();
		Gerald.throwSomething();
		Gerald.displayEnergyA();
		Gerald.eatBananas();
		Gerald.eatBananas();
		Gerald.displayEnergyA();
		Gerald.climb();
		Gerald.displayEnergyA();
		}
}
