src.src
public class BatTest {
	public static void main(String[] args) {
		Bat Spot = new Bat(300);
		Spot.displayEnergyB(); 
		Spot.attackTown();
		Spot.displayEnergyB();
		Spot.attackTown();
		Spot.attackTown();
		Spot.displayEnergyB();
		Spot.eatHumans();
		Spot.eatHumans();
		Spot.displayEnergyB();
		Spot.fly();
		Spot.displayEnergyB();
		Spot.fly();
		Spot.displayEnergyB();

		}
}
